package com.javaWebExam.Utils;

public interface Constants {


}
