package com.javaWebExam.entities.user;

public enum Role {
    USER, ADMIN
}
