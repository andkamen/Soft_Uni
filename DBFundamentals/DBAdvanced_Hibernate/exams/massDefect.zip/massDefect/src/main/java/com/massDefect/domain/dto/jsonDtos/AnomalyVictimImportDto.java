package com.massDefect.domain.dto.jsonDtos;

public class AnomalyVictimImportDto {
    private String id;

    private String person;

    public AnomalyVictimImportDto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }
}
