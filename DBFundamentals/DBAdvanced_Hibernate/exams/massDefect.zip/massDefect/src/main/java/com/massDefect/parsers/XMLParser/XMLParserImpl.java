//package com.massDefect.parsers.XMLParser;
//
//
//import com.sun.org.apache.xerces.internal.parsers.XMLParser;
//
//public class XMLParserImpl implem XMLParser {
//
//    @Override
//    public <T> T readFromXml(Class<T> classes, String fileName){
//
//    }
//}
