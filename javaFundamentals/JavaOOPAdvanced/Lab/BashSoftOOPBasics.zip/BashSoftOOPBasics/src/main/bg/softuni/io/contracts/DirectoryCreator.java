package main.bg.softuni.io.contracts;

public interface DirectoryCreator {

    void createDirectoryInCurrentFolder(String name);

}
