package main.bg.softuni.io.contracts;

public interface DirectoryTraverser {

    void traverseDirectory (int depth);

}
