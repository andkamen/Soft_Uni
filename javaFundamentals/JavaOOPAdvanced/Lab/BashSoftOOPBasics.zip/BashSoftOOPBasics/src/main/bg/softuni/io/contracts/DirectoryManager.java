package main.bg.softuni.io.contracts;

public interface DirectoryManager extends
        DirectoryChanger,
        DirectoryCreator,
        DirectoryTraverser {
}
