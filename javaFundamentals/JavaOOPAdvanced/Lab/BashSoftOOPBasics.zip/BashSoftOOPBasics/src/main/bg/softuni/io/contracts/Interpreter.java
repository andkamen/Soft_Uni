package main.bg.softuni.io.contracts;

public interface Interpreter {

    void interpretCommand(String input) throws Exception;

}
