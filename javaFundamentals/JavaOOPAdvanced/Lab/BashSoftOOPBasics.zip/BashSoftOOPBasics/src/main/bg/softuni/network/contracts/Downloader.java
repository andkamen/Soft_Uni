package main.bg.softuni.network.contracts;

public interface Downloader {

    void download(String fileUrl);

}
