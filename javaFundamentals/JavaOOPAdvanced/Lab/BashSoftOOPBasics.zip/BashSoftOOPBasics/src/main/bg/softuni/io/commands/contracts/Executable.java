package main.bg.softuni.io.commands.contracts;

public interface Executable {

    void execute() throws Exception;

}
