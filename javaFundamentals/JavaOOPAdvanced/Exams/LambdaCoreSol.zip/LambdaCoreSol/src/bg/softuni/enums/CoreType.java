package bg.softuni.enums;

public enum CoreType {
    System,
    Para
}
