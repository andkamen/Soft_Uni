package bg.softuni.interfaces;

public interface InputReader {

    String readLine();
}
