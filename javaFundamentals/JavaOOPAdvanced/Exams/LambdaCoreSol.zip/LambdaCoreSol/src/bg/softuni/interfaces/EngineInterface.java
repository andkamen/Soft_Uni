package bg.softuni.interfaces;

public interface EngineInterface {
    void run();
}
