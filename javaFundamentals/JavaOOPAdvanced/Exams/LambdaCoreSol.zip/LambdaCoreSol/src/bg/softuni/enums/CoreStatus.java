package bg.softuni.enums;

public enum CoreStatus {
    NORMAL,
    CRITICAL
}
