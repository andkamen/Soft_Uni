package bg.softuni.exceptions;

public class NoSelectedCoreException extends LambdaCoreBaseException {

    public NoSelectedCoreException() {
        super();
    }

    public NoSelectedCoreException(String message) {
        super(message);
    }
}
