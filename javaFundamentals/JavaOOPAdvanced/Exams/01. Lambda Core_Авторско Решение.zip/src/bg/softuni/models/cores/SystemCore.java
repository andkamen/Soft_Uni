package bg.softuni.models.cores;

public class SystemCore extends BaseCore{
    public SystemCore(String name, Integer durability) {
        super(name, durability);
    }
}
