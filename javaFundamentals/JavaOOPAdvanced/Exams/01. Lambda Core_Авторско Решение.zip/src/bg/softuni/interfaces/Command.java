package bg.softuni.interfaces;

public interface Command {
    String execute();
}