package bg.softuni.framework.lifecycle.request;

public enum RequestMethod {
    GET,
    ADD,
    EDIT,
    DELETE
}
