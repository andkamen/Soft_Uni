package bg.softuni.io.reader;

import java.io.IOException;

/**
 * Created by RoYaL on 8/2/2016.
 */
public interface Reader {

    String readLine() throws IOException;

}
