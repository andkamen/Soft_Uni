package bg.softuni.io.writer;

/**
 * Created by RoYaL on 8/2/2016.
 */
public interface Writer {

    void writeLine(String line);

}
