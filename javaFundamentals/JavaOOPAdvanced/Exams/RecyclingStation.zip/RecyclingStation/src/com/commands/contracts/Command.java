package com.commands.contracts;

public interface Command {

    String execute();

}
