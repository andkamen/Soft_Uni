package bg.softuni.parser;

public interface Parser {

    void parse();
}
