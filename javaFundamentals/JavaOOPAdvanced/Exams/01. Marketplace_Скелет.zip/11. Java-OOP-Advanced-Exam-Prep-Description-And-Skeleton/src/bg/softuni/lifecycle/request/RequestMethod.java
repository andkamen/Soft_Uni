package bg.softuni.lifecycle.request;

public enum RequestMethod {
    GET,
    ADD,
    EDIT,
    DELETE
}
