package wasteDisposal.enums;

public enum GarbageType {
    RECYCLABLE,
    BURNABLE,
    STORABLE
}
