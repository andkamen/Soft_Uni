package core.contracts;

public interface EngineInterface {

    void run();

}
