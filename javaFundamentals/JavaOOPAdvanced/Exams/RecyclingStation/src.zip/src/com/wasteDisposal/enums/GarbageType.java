package com.wasteDisposal.enums;

public enum GarbageType {
    RECYCLABLE,
    BURNABLE,
    STORABLE
}
