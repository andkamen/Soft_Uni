package com.io.contracts;

public interface InputReader {

    String readLine();

}
