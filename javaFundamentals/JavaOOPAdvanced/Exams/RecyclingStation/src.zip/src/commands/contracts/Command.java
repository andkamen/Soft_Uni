package commands.contracts;

public interface Command {

    String execute();

}
