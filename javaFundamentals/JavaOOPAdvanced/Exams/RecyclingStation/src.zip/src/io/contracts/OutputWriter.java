package io.contracts;

public interface OutputWriter {

    void writeLine(String output);

    void writeLine(String format, String output);

}
