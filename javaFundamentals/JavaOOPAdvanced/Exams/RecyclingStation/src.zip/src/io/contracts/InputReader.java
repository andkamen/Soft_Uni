package io.contracts;

public interface InputReader {

    String readLine();

}
