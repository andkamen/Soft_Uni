package com.Interfaces.FoodShortage.interfaces;

public interface Buyer {
    void BuyFood();
    int getFoodAmount();
}
