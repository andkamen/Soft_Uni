package com.L06Polymorphism.Vehicle.Vehicle;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumption;
    private double distance;

    public Vehicle() {
    }

    public Vehicle(double fuelQuantity, double fuelConsumption) {
        setFuelQuantity(fuelQuantity);
        setFuelConsumption(fuelConsumption);
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public double getDistance() {
        return distance;
    }


    protected void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    protected void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    protected void setDistance(double distance) {
        this.distance = distance;
    }

    public boolean drive(double distance) {
        double maxDistance = getFuelQuantity() / getFuelConsumption();
        if (distance > maxDistance) {
            return false;
        }
        setFuelQuantity(getFuelQuantity() - (getFuelConsumption() * distance));
        setDistance(getDistance()+distance);
        return true;
    }

    public void refuel(double fuel) {
        setFuelQuantity(getFuelQuantity() + fuel);
    }

}
