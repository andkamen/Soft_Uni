package com.L06Polymorphism.Vehicle.Vehicle;

public class Car extends Vehicle {
    private final double FUEL_CONSUMPTION_INCREASE = 0.9;

    public Car(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);

        setFuelConsumption(getFuelConsumption()+FUEL_CONSUMPTION_INCREASE);
    }
}
