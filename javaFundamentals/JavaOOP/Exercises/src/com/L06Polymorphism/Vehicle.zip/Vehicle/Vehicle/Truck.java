package com.L06Polymorphism.Vehicle.Vehicle;

public class Truck extends Vehicle {
    private final double FUEL_CONSUMPTION_INCREASE = 1.6;

    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption);

        setFuelConsumption(getFuelConsumption()+FUEL_CONSUMPTION_INCREASE);
    }

    @Override
    public void refuel(double fuel) {
        super.refuel(fuel*0.95);
    }
}
