package com.L03StaticMembers.BasicMath;

public class MathUtils {
    public static double sum(double firstNum, double secondNum) {
        return firstNum + secondNum;
    }

    public static double subtract(double firstNum, double secondNum) {
        return firstNum - secondNum;
    }

    public static double multiply(double firstNum, double secondNum) {
        return firstNum * secondNum;
    }

    public static double divide(double firstNum, double secondNum) {
        return firstNum / secondNum;
    }

    public static double percentage(double firstNum, double secondNum) {
        return firstNum * secondNum/100;
    }
}
