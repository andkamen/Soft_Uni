package com.StaticData;

public class SessionData {
    public static String currentPath = System.getProperty("user.dir");
}
