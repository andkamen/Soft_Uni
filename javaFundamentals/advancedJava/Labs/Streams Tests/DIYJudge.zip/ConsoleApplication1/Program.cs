﻿namespace SimpleJudge
{
    class Program
    {
        public static void Main()
        {
            
        }
    }
}
